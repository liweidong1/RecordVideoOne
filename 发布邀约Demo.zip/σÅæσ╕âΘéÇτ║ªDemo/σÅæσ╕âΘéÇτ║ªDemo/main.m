//
//  main.m
//  发布邀约Demo
//
//  Created by bobo on 2016/10/10.
//  Copyright © 2016年 bobo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
