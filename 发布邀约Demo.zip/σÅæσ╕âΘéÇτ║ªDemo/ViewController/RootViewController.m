//
//  RootViewController.m
//  发布邀约Demo
//
//  Created by bobo on 2016/10/10.
//  Copyright © 2016年 bobo. All rights reserved.
//

#import "RootViewController.h"
#import "InvitationViewController.h"
@interface RootViewController ()

@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=@"这是标题";
    self.view.backgroundColor=[UIColor orangeColor];
    
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    InvitationViewController* i=[[InvitationViewController alloc]init];
    [self.navigationController pushViewController:i animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
