//
//  InvitationViewController.m
//  发布邀约Demo
//
//  Created by bobo on 2016/10/10.
//  Copyright © 2016年 bobo. All rights reserved.
//

#import "InvitationViewController.h"
#import "AddFriendViewController.h"
#import "GetFilePath.h"
#import "GCMImagePickerController.h"

#import "GCMAssetsGroupController.h"

//Masonry库的两个宏，注意：必须声明在Masonry头文件之上，声明后在使用库方法时可省略mas前缀
#define MAS_SHORTHAND
#define MAS_SHORTHAND_GLOBALS
#import "Masonry.h"

//播放器头文件
#import <MediaPlayer/MediaPlayer.h>

//三方视频播放
#import "KrVideoPlayerController.h"

//tableView中各个cell的高度
#define one_three_cell_height (ScreenH-64)/3/3-20//1-3 cell
#define four_cell_height (ScreenH-64)/3-5+40
#define five_cell_height (ScreenH-64)/3+15+20

//屏幕的高宽
#define ScreenW [UIScreen mainScreen].bounds.size.width
#define ScreenH [UIScreen mainScreen].bounds.size.height

@interface InvitationViewController ()<UITableViewDataSource,UITableViewDelegate,UINavigationControllerDelegate, UIImagePickerControllerDelegate>
{
    UILabel* _invitationTime;//显示邀请时间
    NSMutableArray* _friendImageArray;//存放邀约到的好友信息（头像图片，好友名称）
    //播放器的原点坐标
    float x,y;
}
@property (nonatomic, strong) KrVideoPlayerController  *videoController;//三方播放器控制器

@end

@implementation InvitationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title=@"发布邀约";
    [self.navigationController.navigationBar setBackgroundColor:[UIColor whiteColor]];
    
    [self createGapView];//创建tableView和导航栏之间的空隙视图
    [self createTableView];//创建TableView视图
}

#pragma -mark ---创建tableView和导航栏之间的空隙视图---
-(void)createGapView{
    UILabel* gap=[[UILabel alloc]initWithFrame:CGRectMake(0, 64, ScreenW, 10)];
    gap.backgroundColor=[UIColor colorWithRed:244.0/255.0 green:244.0/255.0 blue:244.0/255.0 alpha:1];;
    [self.view addSubview:gap];
}

#pragma -mark ---创建tableView视图---
-(void)createTableView{
    _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0,74, ScreenW, ScreenH) style:UITableViewStylePlain];
    _tableView.delegate=self;
    _tableView.dataSource=self;
    
    [self.view addSubview:_tableView];
}

#pragma -mark  ---TableView协议方法，创建且设置cell样式---
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell* cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if(cell==nil)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }

    if(indexPath.row==0){
        
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        cell.textLabel.text=@"邀约时间";
        _invitationTime=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenW, one_three_cell_height)];
        _invitationTime.text=@"2016/10/1~2016/11/1";
        _invitationTime.alpha=0.5;
        _invitationTime.font=[UIFont systemFontOfSize:15];
        [cell.contentView addSubview:_invitationTime];

        [_invitationTime makeConstraints:^(MASConstraintMaker *make) {
           
            make.right.equalTo(cell.right).offset(-30);
            make.centerY.equalTo(cell.centerY);
//            make.left.equalTo(cell.left).offset(150);
            make.size.width.equalTo(150);
        }];
        
        
    }else if (indexPath.row==1){
        
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        cell.textLabel.text=@"去哪";
        
    }else if(indexPath.row==2){
        
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        cell.textLabel.text=@"邀约形式";
        
    }else if (indexPath.row==3){
        //取消cell点击效果
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.tag=10;//设置第四个cell的tag值
        cell.backgroundColor=[UIColor colorWithRed:244.0/255.0 green:244.0/255.0 blue:244.0/255.0 alpha:1];
        
        //第四个cell上显示播放器和播放器底部文字的视图showVideoViewButton
        UIButton* showVideoViewButton=[UIButton buttonWithType:UIButtonTypeCustom];
        showVideoViewButton.tag=11;
        
        //在未播放视频前，显示的图片
        UIImageView* videoPlayView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0,50,50)];//原点和大小坐标必须写（随意写），否则下面不能对该视图进行约束
        videoPlayView.image=[UIImage imageNamed:@"1.png"];
        videoPlayView.backgroundColor=[UIColor yellowColor];
        videoPlayView.layer.cornerRadius=5;
        videoPlayView.clipsToBounds=YES;
        videoPlayView.tag=12;

        //播放器底部的文字展示
        UILabel* label=[[UILabel alloc]init];
        label.font=[UIFont systemFontOfSize:13];
        label.text=@"录制您心仪的短视频";

        //将播放器位置的显示图片和播放器底部文字视图添加到showVideoViewButton上
        [showVideoViewButton addSubview:videoPlayView];
        [showVideoViewButton addSubview:label];
        [cell.contentView addSubview:showVideoViewButton];

        //对showVideoViewButton进行布局约束
        [showVideoViewButton makeConstraints:^(MASConstraintMaker *make) {
            make.size.equalTo(CGSizeMake(ScreenW/4*3, four_cell_height-30));
            make.centerY.equalTo(cell.centerY);
            make.left.equalTo(cell.left).offset(20);
        }];
        //对videoPlayView进行布局约束
        [videoPlayView makeConstraints:^(MASConstraintMaker *make) {

            make.size.width.equalTo(100);
            make.right.equalTo(showVideoViewButton.right).offset(-10);
            make.left.equalTo(showVideoViewButton.left).offset(10);
            make.top.equalTo(showVideoViewButton.top).offset(5);
            make.bottom.equalTo(showVideoViewButton.bottom).offset(-18);
           
        }];
        
        //对播放器底部显示文字视图进行布局约束
        [label makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(showVideoViewButton.bottom).offset(-2);
            make.left.equalTo(showVideoViewButton.left).offset(10);
            
        }];
        
        //创建拍摄按钮
        UIButton* takeVideo=[UIButton buttonWithType:UIButtonTypeCustom];
        [takeVideo setTitle:@"拍摄" forState:UIControlStateNormal];
        takeVideo.backgroundColor=[UIColor orangeColor];
        [takeVideo addTarget:self action:@selector(takeClick) forControlEvents:UIControlEventTouchUpInside];
        
        //创建添加视频按钮
        UIButton* addVideo=[UIButton buttonWithType:UIButtonTypeCustom];
        addVideo.backgroundColor=[UIColor orangeColor];
        [addVideo setTitle:@"添加" forState:UIControlStateNormal];
        [addVideo addTarget:self action:@selector(addClick) forControlEvents:UIControlEventTouchUpInside];
        [cell.contentView addSubview:takeVideo];
        [cell.contentView addSubview:addVideo];
        
        //对两个按钮进行相关布局约束 ---《设置按钮大小的约束没有成功》---
        [takeVideo makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(showVideoViewButton.right);
            make.top.equalTo(showVideoViewButton.top);
       }];
        [addVideo makeConstraints:^(MASConstraintMaker *make) {
           
            make.top.equalTo(takeVideo.bottom).offset(10);
            make.left.equalTo(showVideoViewButton.right);
            
        }];
        
    }else if(indexPath.row==4){
        //取消cell点击效果
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

        //创建存放“旅途邀约”和“添加好友”视图的视图
        UIView* titleView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenW,(five_cell_height)/4)];
        UIImageView* titleImage=[[UIImageView alloc]init];
        titleImage.backgroundColor=[UIColor yellowColor];
        [titleView addSubview:titleImage];
        
        [titleImage makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(titleView.left).offset(10);
            make.size.equalTo(CGSizeMake(50, 50));
            make.centerY.equalTo(titleView.centerY);
        }];
        
        UILabel* title=[[UILabel alloc]init];
        title.text=@"旅途邀约";
        title.font=[UIFont systemFontOfSize:17];
        [titleView addSubview:title];
        
        [title makeConstraints:^(MASConstraintMaker *make) {
            make.size.equalTo(CGSizeMake(150, 40));
            make.centerY.equalTo(titleView.centerY);
            make.left.equalTo(titleImage.right);
        }];
        
        UIButton* addButton=[UIButton buttonWithType:UIButtonTypeCustom];
        [addButton setTitle:@"添加" forState:UIControlStateNormal];
        addButton.backgroundColor=[UIColor yellowColor];
        [addButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [addButton setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
        [addButton addTarget:self action:@selector(onClickAdd) forControlEvents:UIControlEventTouchUpInside];
        [titleView addSubview:addButton];
        
        [addButton makeConstraints:^(MASConstraintMaker *make) {
           
            make.size.equalTo(CGSizeMake(60, 50));
            make.centerY.equalTo(titleView.centerY);
            make.right.equalTo(titleView.right).offset(-10);
        }];
        
        [cell.contentView addSubview: titleView];
        
        
        //实例化存放好友信息的数组
        _friendImageArray=[[NSMutableArray alloc]init];
        
        //伪数据
        [_friendImageArray addObject:@[@"http://img5.duitang.com/uploads/item/201610/01/20161001155614_NFYEK.thumb.700_0.jpeg",@"One个人的回忆"]];
        [_friendImageArray addObject:@[@"http://pic.yesky.com/uploadImages/2014/337/38/3775YF3CG61M.jpg",@"Two个人的回忆"]];
        [_friendImageArray addObject:@[@"http://img5.duitang.com/uploads/item/201610/01/20161001155614_NFYEK.thumb.700_0.jpeg",@"Three个人的回忆"]];
        [_friendImageArray addObject:@[@"http://pic.yesky.com/uploadImages/2014/337/38/3775YF3CG61M.jpg",@"Two个人的回忆"]];
        [_friendImageArray addObject:@[@"http://img5.duitang.com/uploads/item/201610/01/20161001155614_NFYEK.thumb.700_0.jpeg",@"One个人的回忆"]];
        [_friendImageArray addObject:@[@"http://pic.yesky.com/uploadImages/2014/337/38/3775YF3CG61M.jpg",@"Three个人的回忆"]];
        
        //创建滚动视图，用于可以滚动展示好友头像和名称
        UIScrollView* scrollView=[[UIScrollView alloc]init];
        
        float scrollViewHeight=(five_cell_height)/4*3-10;
        float scrollViewWidth=ScreenW-30;
        float gap=10;
        float imageWidth=(scrollViewWidth-2*gap)/3;
        float imageHeight=scrollViewHeight/5*4;
        
        //滚动视图的contentsize是由存放好友信息数组中好友个数决定的
        scrollView.contentSize=CGSizeMake(_friendImageArray.count*imageWidth+(_friendImageArray.count-1)*gap, scrollViewHeight);
        scrollView.pagingEnabled=YES;
        for(int i=0;i<_friendImageArray.count;i++)
        {
            UIButton* imageBtn=[[UIButton alloc]init];
            imageBtn.tag=100+i;
            [imageBtn addTarget:self action:@selector(onClickFriendDetail:) forControlEvents:UIControlEventTouchUpInside];
           
            UIImageView* imageView=[[UIImageView alloc]init];
            imageView.backgroundColor=[UIColor orangeColor];
            imageView.frame=CGRectMake(0, 0, imageWidth, imageHeight-20);
            UILabel* label=[[UILabel alloc]initWithFrame:CGRectMake(0, imageHeight-20,imageWidth, 20)];
            label.alpha=0.7;
            label.font=[UIFont systemFontOfSize:13];
            label.text=_friendImageArray[i][1];
            [imageBtn addSubview:imageView];
            [imageBtn addSubview:label];
            
            [label makeConstraints:^(MASConstraintMaker *make) {
                make.bottom.equalTo(imageBtn.bottom);
                make.centerX.equalTo(imageBtn.centerX);
            }];
            
            if(i==0){
                imageBtn.frame=CGRectMake(0, 0, imageWidth, imageHeight);
            }else{
                imageBtn.frame=CGRectMake(i*(imageWidth+gap), 0, imageWidth, imageHeight);
            }
            
            
            [scrollView addSubview:imageBtn];

        }
        
        [cell.contentView addSubview:scrollView];
        [scrollView makeConstraints:^(MASConstraintMaker *make) {
            make.size.equalTo(CGSizeMake(scrollViewWidth,scrollViewHeight ));
            make.centerX.equalTo(cell.centerX);
            make.bottom.equalTo(cell.bottom);
        }];
        
    }
    return cell;
}
#pragma -mark ---点击事件-跳转二级界面
-(void)onClickAdd{
    NSLog(@"clicked!!!");
    AddFriendViewController* add=[[AddFriendViewController alloc]init];
    [self.navigationController pushViewController:add animated:YES];
}
-(void)onClickFriendDetail:(UIButton*)btn
{
    AddFriendViewController* add=[[AddFriendViewController alloc]init];
    [self.navigationController pushViewController:add animated:YES];
}

#pragma -mark ---开始拍摄按钮点击事件
-(void)takeClick{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        picker.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeCamera];
        picker.videoQuality = UIImagePickerControllerQualityTypeMedium; //录像质量
        picker.videoMaximumDuration = 15.0f; //录像最长时间
        picker.mediaTypes = [NSArray arrayWithObjects:@"public.movie", nil];
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"当前设备不支持录像功能" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alert show];
    }
    //跳转到拍摄页面
    [self presentViewController:picker animated:YES completion:nil];
}

#pragma -mark ---根据url播放视频
- (void)addVideoPlayerWithURL:(NSURL *)url{
    
    //获取播放器的准确位置：要求播放器跟tag值为11的视图重合
    UITableViewCell* cell=(UITableViewCell*)[self.view viewWithTag:10];
    UIButton* button=(UIButton*)[self.view viewWithTag:11];
    UIImageView* imageView=(UIImageView*)[self.view viewWithTag:12];
    
    //播放器的原点坐标
    x=cell.frame.origin.x+button.frame.origin.x+imageView.frame.origin.x;
    y=cell.frame.origin.y+button.frame.origin.y+imageView.frame.origin.y+64+10;//加上状态栏跟导航栏和gap的高度
  
    if (!self.videoController) {
//        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        self.videoController = [[KrVideoPlayerController alloc] initWithFrame:CGRectMake(x, y, imageView.frame.size.width,imageView.frame.size.height)];
        __weak typeof(self)weakSelf = self;
        [self.videoController setDimissCompleteBlock:^{
            weakSelf.videoController = nil;
        }];
        [self.videoController setWillBackOrientationPortrait:^{
            [weakSelf toolbarHidden:NO];
        }];
        [self.videoController setWillChangeToFullscreenMode:^{
            [weakSelf toolbarHidden:YES];
        }];
        [self.view addSubview:self.videoController.view];
    }
    self.videoController.contentURL = url;
    
}
#pragma -mark ---隐藏navigation tabbar 电池栏
- (void)toolbarHidden:(BOOL)Bool{
    self.navigationController.navigationBar.hidden = Bool;
    self.tabBarController.tabBar.hidden = Bool;
    [[UIApplication sharedApplication] setStatusBarHidden:Bool withAnimation:UIStatusBarAnimationFade];
}
#pragma -mark ---当屏幕开始滚动式固定播放器的位置跟tag=13的视图保持一致
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    UIImageView* imageView=(UIImageView*)[self.view viewWithTag:12];

    self.videoController.frame=CGRectMake(x, y-_tableView.contentOffset.y,imageView.frame.size.width,imageView.frame.size.height);
}
#pragma -mark ---添加视频点击事件
-(void)addClick{
    GCMAssetsGroupController* gc=[[GCMAssetsGroupController alloc]init];
    gc.title=@"选择相册";
    [self.navigationController pushViewController:gc animated:YES];

}
//拍摄协议
#pragma -mark ---拍摄完成后要执行的代理方法
// chose选中某张图片,内含参数info,图片的信息.(选中后调用此方法)
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
//        //进入视频/照片库选完之后播放视频
//    //视频开始播放
//    NSURL* url=[[NSBundle mainBundle]URLForResource:@"150511_JiveBike" withExtension:@"mov"];
//    [self addVideoPlayerWithURL:url];

    //保存拍摄视频
    NSString *mediaType = [info objectForKey:UIImagePickerControllerMediaType];
    BOOL success;
    NSFileManager *fileManager = [NSFileManager defaultManager];

    if ([mediaType isEqualToString:@"public.movie"]) {
        NSString *videoPath = [GetFilePath getSavePathWithFileSuffix:@"mov"];
        success = [fileManager fileExistsAtPath:videoPath];
        if (success) {
            [fileManager removeItemAtPath:videoPath error:nil];
        }
        
        NSURL *videoURL = [info objectForKey:UIImagePickerControllerMediaURL];

        //将拍摄的视频存入相册
        UISaveVideoAtPathToSavedPhotosAlbum(videoPath, self, nil, nil);//将拍摄的视频存入相册
        
        
        NSData *videlData = [NSData dataWithContentsOfURL:videoURL];
        NSLog(@"--------data.length=%lu",(unsigned long)videlData.length);
        [videlData writeToFile:videoPath atomically:YES]; //写入本地
        //存储数据
        success = [fileManager fileExistsAtPath:videoPath];
        if (success) {
            NSLog(@"media 写入成功,video路径:%@",videoPath);
        }

    }
    NSLog(@"拍摄完毕！！！:%@",info[UIImagePickerControllerMediaURL]);
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma -mark ---进入拍摄页面点击取消按钮
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"点击了取消按钮！！！");
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma -mark --- TableView的协议方法，设置cell的个数
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}

#pragma -mark --- TableView的协议方法，设置各个cell的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row==3){
        return four_cell_height;
    }else if(indexPath.row==4){
        return five_cell_height;
    }else{
        return one_three_cell_height;
    }
}

#pragma -mark --- TableView的协议方法，设置cell的点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row==0){
        AddFriendViewController* add=[[AddFriendViewController alloc]init];
        [self.navigationController pushViewController:add animated:YES];
    }else if(indexPath.row==1){
        AddFriendViewController* add=[[AddFriendViewController alloc]init];
        [self.navigationController pushViewController:add animated:YES];
    }else if (indexPath.row==2){
        AddFriendViewController* add=[[AddFriendViewController alloc]init];
        [self.navigationController pushViewController:add animated:YES];
    }
}
@end
