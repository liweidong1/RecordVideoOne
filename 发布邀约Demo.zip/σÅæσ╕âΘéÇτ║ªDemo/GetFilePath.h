//
//  GetFilePath.h
//  调用系统自带的摄像功能Demo
//
//  Created by bobo on 2016/10/11.
//  Copyright © 2016年 bobo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface GetFilePath : NSObject
//获取要保存的本地文件路径
+ (NSString *)getSavePathWithFileSuffix:(NSString *)suffix;
//获取录像的缩略图
+ (UIImage *)getVideoThumbnailWithFilePath:(NSString *)filePath;
+ (UIImage *)getImage:(NSString *)filePath;
@end
