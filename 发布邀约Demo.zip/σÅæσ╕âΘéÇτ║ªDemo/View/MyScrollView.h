//
//  MyScrollView.h
//  发布邀约Demo
//
//  Created by bobo on 2016/10/10.
//  Copyright © 2016年 bobo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyScrollView : UIScrollView

@end
